MANRAJ Phase 2C - REBUILT static demo (iPhone + Android)
=========================================================
Files: index.html (standalone page; no external dependencies)

HOW TO PUT IT ON GITHUB PAGES FROM IPHONE
1. Open https://github.com/Sainipariwar/manraj-app-demo/upload/main in Safari.
2. Choose Files and select THIS new index.html (not the old MANRAJ-Phase2C...html).
3. Review the filename. Commit directly to the main branch.
4. Wait for GitHub Pages to update (usually a few minutes).
5. Visit https://sainipariwar.github.io/manraj-app-demo/ in Safari.
   If it still shows the older page, refresh the page or open a private tab.

DEMO TEST
- Customer -> choose Rajmistri / Kadiya -> fill fictional name/address -> Create demo booking.
- Admin -> choose a matching fictional mason -> Assign worker.
- Partner -> select assigned demo worker -> Accept -> On the way -> In progress -> Complete.
- Admin -> verify Completed status.
- Optional OTP test: Generate demo OTP, type it, Verify. No SMS sent.
- Optional GPS test: asks permission over HTTPS and shows approximate accuracy only.

SAFETY AND LIMITATIONS
- Public GitHub Pages is NOT private hosting. Do not enter real customer or worker info.
- No real authentication, OTP SMS, payments, dispatch or live tracking.
- All booking data is fictional and stored in browser localStorage on one device only.
- Never use this prototype as a production application.
- No Hostinger website or DNS changes needed.
