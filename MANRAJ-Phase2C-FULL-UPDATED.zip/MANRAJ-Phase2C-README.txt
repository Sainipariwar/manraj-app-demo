MANRAJ — Phase 2C Mobile Service Marketplace (Static Demo)
========================================================

UPLOAD TO GITHUB (IPHONE)
1. Download and SAVE index.html (the standalone file, NOT a ZIP).
2. Open https://github.com/Sainipariwar/manraj-app-demo/upload/main in Safari.
3. Choose your files > Browse > select index.html.
4. Commit changes to main branch.
5. Wait for GitHub Pages deployment and open https://sainipariwar.github.io/manraj-app-demo/
6. If you still see README, refresh the site; verify index.html exists at repository root.

FEATURES
* Mobile-first responsive customer, partner and admin role views.
* Search and filter 13 fictional service categories, favourites, service details.
* Demo booking with fictional alias/address/date/slot/duration, mock bill.
* Worker suggestions by demo Surat locality, admin assignment and partner workflow.
* Demo status tracking, notifications, saved bookings in local browser storage.
* Simulated on-screen 6-digit OTP test; GPS permission test (no coordinates stored).
* No paid service, backend, phone SMS, transaction, or live partner dispatch.

IMPORTANT LIMITATIONS
* GitHub Pages is publicly accessible. Do not enter real customer names,
  phone numbers, exact addresses, secrets, OTPs, or business credentials.
* Roles are not authenticated; this is not a production login system.
* Demo bookings reside ONLY in the local browser's localStorage: no cross-device sync.
* Demo workers, rates, places and earnings are fictional.
* The GPS permission test does not store/track/send coordinates and does not
  affect nearby matching, which uses selected demo localities.
* HTML file preview in the iPhone Files app can block JavaScript. Test via HTTPS.
* For real OTP/GPS worker tracking/back-end bookings: separate secure API,
  database, identity provider, SMS service and privacy design are required.
* Hostinger domain, DNS and current website are not affected by GitHub Pages.
